import React from "react";

function Home() {
  return (
    <>
      <div className="aboutcontent">
        
      </div>
    </>
  );
}

export default Home;
